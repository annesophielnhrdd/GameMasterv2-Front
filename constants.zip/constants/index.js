export { COLORS } from './COLORS';
export { GLOBAL_STYLES } from './GLOBAL_STYLE';
