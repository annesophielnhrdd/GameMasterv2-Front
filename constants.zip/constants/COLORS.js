export const COLORS = {
  white: '#FFF', // White
  black: '#000', // Black
  primary: '#5D726F', // Medium Grey
  secondary: '#efefef', // Dark white
};
